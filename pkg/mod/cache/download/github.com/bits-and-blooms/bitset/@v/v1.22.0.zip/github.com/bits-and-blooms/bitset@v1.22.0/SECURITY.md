# Security Policy

## Reporting a Vulnerability

You can report privately a vulnerability by email at daniel@lemire.me (current maintainer).

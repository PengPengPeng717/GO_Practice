---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

<!--
Remember to include a code sample that reproduces the bug, if possible.

Love colly? Please consider supporting our collective:
👉  https://opencollective.com/colly/donate
-->
